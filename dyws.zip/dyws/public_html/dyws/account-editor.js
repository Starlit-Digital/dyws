import {formatTime} from './date-time.js';
import {escapeHTML as esc} from './api.js';
import {defaultRole} from './role-labels.js';
import {adminPage} from './admin-navigation.js?v=37';
export async function mountDriverAdmin({root=document,api,storageKey,role=defaultRole,createLocationRenderer}) {
 const page=adminPage({root,api,storageKey});if(!page.token)return;
 const form=root.querySelector('#driver-form'),list=root.querySelector('#drivers-list'),message=root.querySelector('#driver-message');let revision,drivers=[],locations=[],refreshing=false;const maps=new Map();
 function drawLocations(){for(const card of list.querySelectorAll('[data-driver-id]')){const id=card.dataset.driverId,location=locations.find(l=>l.driverId===id&&l.gps?.location)||locations.find(l=>l.driverId===id);card.querySelector('.dyws-driver-location-status').textContent=location?location.orderId+' · '+(location.gps?.location?(location.gps.source==='simulated'?'Simulated GPS test':'Device GPS')+(location.gps.stale?' · Last known position':'')+' · '+formatTime(location.gps.recordedAt):'Waiting for a current GPS fix.'):'No delivery currently on the way.';if(createLocationRenderer){if(!maps.has(id))maps.set(id,createLocationRenderer());const node=maps.get(id)(location?.gps?.location||null,role,{destinationAddress:location?.deliveryAddress}),container=card.querySelector('.dyws-driver-location-map');if(node&&!container.contains(node))container.replaceChildren(node);}}}
 async function refreshLocations(){if(refreshing)return;refreshing=true;try{locations=(await page.request('/manager/driver-locations')).locations;drawLocations();}catch(e){if([401,403].includes(e.status)){for(const map of maps.values())map.clear?.();}page.error.textContent=e.message;}finally{refreshing=false;}}
 function edit(driver){root.querySelector('#driver-editor').hidden=false;form.reset();form.elements.id.readOnly=!!driver;form.elements.id.value=driver?.id||'';form.elements.name.value=driver?.name||'';form.elements.active.checked=driver?.active??true;form.elements.password.required=!driver;root.querySelector('#driver-form-title').textContent=(driver?'Edit ':'Add ')+role.singular;form.elements.name.focus();}
 function display(data){revision=data.revision;drivers=data.drivers;list.innerHTML=drivers.length?drivers.map((d,i)=>`<article class="dyws-driver-card" data-driver-id="${esc(d.id)}"><div class="dyws-driver-card-details"><h3>${esc(d.name)}</h3><p>${esc(d.id)} · ${d.active?'Active':'Inactive'}</p><p>${d.activeOrders} active ${d.activeOrders===1?'order':'orders'}</p><button type="button" data-edit="${i}" class="dyws-secondary">Edit</button></div><div class="dyws-driver-location"><p class="dyws-driver-location-status" role="status"></p><div class="dyws-driver-location-map"></div></div></article>`).join(''):`<p>No ${esc(role.plural)} yet. Add your first ${esc(role.singular)} below.</p>`;for(const [id,map]of maps)if(!drivers.some(d=>d.id===id)){map.destroy?.();maps.delete(id);}drawLocations();}
 list.onclick=event=>{const button=event.target.closest('[data-edit]');if(button)edit(drivers[Number(button.dataset.edit)]);};
 root.querySelector('#new-driver').onclick=()=>edit();
 root.querySelector('#cancel-driver').onclick=()=>{root.querySelector('#driver-editor').hidden=true;root.querySelector('#new-driver').focus();};
 root.querySelector('#reload-drivers').onclick=event=>page.action(event.target,async()=>{display(await page.request('/manager/drivers'));message.textContent=role.plural+' reloaded.';});
 form.onsubmit=event=>{event.preventDefault();page.action(event.submitter,async()=>{const body={create:!form.elements.id.readOnly,id:form.elements.id.value.trim(),name:form.elements.name.value.trim(),active:form.elements.active.checked,password:form.elements.password.value,revision};const data=await page.request('/manager/drivers',{method:'POST',body});display(data);edit(drivers.find(d=>d.id===body.id));message.textContent=role.singular+' saved.';});};
 try{display(await page.request('/manager/drivers'));await refreshLocations();}catch(e){page.error.textContent=e.message;}
 const stop=api.watch?.({scope:'operator',token:page.token,interval:10000},refreshLocations);const timer=!api.watch?setInterval(refreshLocations,10000):null;
 return {destroy(){stop?.();clearInterval(timer);for(const map of maps.values())map.destroy?.();}};
}
export function mountPasswordAdmin({root=document,api,storageKey}) {
 const page=adminPage({root,api,storageKey});if(!page.token)return;
 const form=root.querySelector('#password-form'),message=root.querySelector('#password-message');
 form.onsubmit=event=>{event.preventDefault();page.action(event.submitter,async()=>{const body=Object.fromEntries(new FormData(form));if(body.newPassword!==body.confirmPassword)throw new Error('The new passwords do not match.');await page.request('/manager/password',{method:'POST',body});form.reset();page.signOut();message.textContent='Password changed. Sign in again with your new password.';});};
}
