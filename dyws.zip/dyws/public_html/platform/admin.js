import {markReady} from '../dyws/diagnostics.js';
import {redirectToAuth} from '../dyws/admin-session.js?v=39';
import {plugins} from './plugins.js?v=39';
import {mountNavigation} from './admin-navigation.js?v=39';
import {api} from './api.js';
import {loadRole,applyRoleLabels} from '../dyws/role-labels.js';
const role=await loadRole(api);
applyRoleLabels(document.body,role);
if(document.body.dataset.adminPage==='drivers')document.title=role.plural+' | dyws';
const current=document.body.dataset.adminPage;
mountNavigation(current,role);
const loaders={catalog:()=>import('../dyws/catalog-editor.js?v=39'),drivers:()=>import('../dyws/account-editor.js?v=39'),password:()=>import('../dyws/account-editor.js?v=39'),settings:()=>import('../dyws/general-settings.js?v=39'),plugins:()=>import('../dyws/plugin-admin.js?v=39')};
const names={catalog:'mountCatalogEditor',drivers:'mountDriverAdmin',password:'mountPasswordAdmin',settings:'mountGeneralSettings',plugins:'mountPluginAdmin'};
const page=await loaders[current]?.();
await page?.[names[current]]?.({root:document.body,api,role,createLocationRenderer:()=>plugins.createLocationRenderer({api,defaultCenter:{lat:53.61665,lng:-113.39804}}),onSave:settings=>mountNavigation(current,settings.driverRole)});

if(current==='settings'&&sessionStorage.getItem('dyws-manager'))await plugins.runAction('admin:settings',{root:document.body,api});
markReady();
if(plugins.errors.length)document.querySelector('[data-admin-error]').textContent=plugins.errors.join(' ');
const operator=sessionStorage.getItem('dyws-manager');
if(operator){
 let previous;
 const routes={catalog:'/manager/catalog',drivers:'/manager/drivers',settings:'/manager/settings',plugins:'/manager/plugins'};
 const seeded=JSON.parse(document.querySelector('meta[name="dyws-admin-data"]')?.content||'null');if(routes[current]&&seeded?.responses[routes[current]])previous=JSON.stringify(seeded.responses[routes[current]]);
 api.watch({scope:'operator',token:operator,interval:15000},async event=>{
  if(event.type==='auth-error'&&[401,403].includes(event.status)){redirectToAuth();return;}
  const settings=await api('/settings');mountNavigation(current,settings.driverRole);
  if(!routes[current])return;
  const data=await api(routes[current],{token:operator});const signature=JSON.stringify(data);
  if(previous!==undefined&&signature!==previous){let notice=document.querySelector('[data-dyws-update-notice]');if(!notice){notice=document.createElement('p');notice.dataset.dywsUpdateNotice='true';notice.className='dyws-update-notice';notice.setAttribute('role','status');document.querySelector('main').prepend(notice);}notice.textContent='Updates available. Reload when ready.';}
  previous=signature;
 });
}
